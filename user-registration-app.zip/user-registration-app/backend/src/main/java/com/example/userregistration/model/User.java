package com.example.userregistration.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * User.java - The Model / Entity class
 *
 * This class represents a User document stored in MongoDB.
 *
 * @Document(collection = "users") tells Spring Data MongoDB:
 *   → Save/read documents from the "users" collection
 *   → Inside the "userdb" database (set in application.properties)
 *
 * Each field in this class = a field in the MongoDB document.
 */
@Document(collection = "users")
public class User {

    /**
     * @Id marks this field as the MongoDB document's unique identifier (_id).
     * MongoDB auto-generates this as a 24-character hex string if not provided.
     */
    @Id
    private String id;

    // The unique user ID provided by the user (e.g., "user001")
    private String userId;

    // Login username (e.g., "john_doe")
    private String username;

    // Password - In real apps, NEVER store plain-text passwords. Use BCrypt.
    private String password;

    // Full name of the user
    private String name;

    // City where the user lives
    private String city;

    // Date of birth in format "YYYY-MM-DD"
    private String dateOfBirth;

    // ---- Constructors ----

    // No-argument constructor: required by Spring Data
    public User() {}

    // All-arguments constructor: convenient way to create a full User object
    public User(String userId, String username, String password,
                String name, String city, String dateOfBirth) {
        this.userId      = userId;
        this.username    = username;
        this.password    = password;
        this.name        = name;
        this.city        = city;
        this.dateOfBirth = dateOfBirth;
    }

    // ---- Getters & Setters ----
    // Getters allow reading field values; Setters allow writing them.
    // Spring uses these to convert JSON ↔ Java objects automatically.

    public String getId()                        { return id; }
    public void   setId(String id)               { this.id = id; }

    public String getUserId()                    { return userId; }
    public void   setUserId(String userId)       { this.userId = userId; }

    public String getUsername()                  { return username; }
    public void   setUsername(String username)   { this.username = username; }

    public String getPassword()                  { return password; }
    public void   setPassword(String password)   { this.password = password; }

    public String getName()                      { return name; }
    public void   setName(String name)           { this.name = name; }

    public String getCity()                      { return city; }
    public void   setCity(String city)           { this.city = city; }

    public String getDateOfBirth()               { return dateOfBirth; }
    public void   setDateOfBirth(String dob)     { this.dateOfBirth = dob; }

    // toString: Useful for printing the object in logs
    @Override
    public String toString() {
        return "User{id='" + id + "', userId='" + userId + "', username='" + username +
               "', name='" + name + "', city='" + city + "', dateOfBirth='" + dateOfBirth + "'}";
    }
}
