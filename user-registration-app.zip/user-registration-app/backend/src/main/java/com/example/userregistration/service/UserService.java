package com.example.userregistration.service;

import com.example.userregistration.model.User;
import com.example.userregistration.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * UserService.java - The Service Layer
 *
 * The Service layer sits between the Controller and the Repository.
 * It contains the BUSINESS LOGIC of the application.
 *
 * Think of it this way:
 *   Controller → receives HTTP request
 *   Service    → processes the request (validation, logic)
 *   Repository → saves/fetches data from MongoDB
 *
 * @Service tells Spring: "This is a service component. Manage it for me."
 */
@Service
public class UserService {

    /**
     * @Autowired tells Spring to automatically inject the UserRepository bean.
     * We don't need to create it with "new" — Spring handles that.
     */
    @Autowired
    private UserRepository userRepository;

    /**
     * Save a new user to MongoDB.
     *
     * This method:
     *   1. Receives a User object (sent from the controller)
     *   2. Calls repository.save() to persist it in MongoDB
     *   3. Returns the saved user (which now has a MongoDB-generated _id)
     *
     * @param user - The user object to save
     * @return     - The saved user with the generated _id field
     */
    public User registerUser(User user) {
        // Log that we're about to save (helpful for debugging)
        System.out.println("📝 Saving user: " + user.getUsername());

        // Call the repository to save the user in MongoDB
        User savedUser = userRepository.save(user);

        // Log success
        System.out.println("✅ User saved with ID: " + savedUser.getId());

        return savedUser;
    }

    /**
     * Find all users in the database.
     * Useful for an admin dashboard or listing all users.
     *
     * @return List of all users
     */
    public java.util.List<User> getAllUsers() {
        return userRepository.findAll();
    }

    /**
     * Find a specific user by their userId field.
     *
     * @param userId - The custom userId (not the MongoDB _id)
     * @return User object if found, or null if not found
     */
    public User getUserByUserId(String userId) {
        return userRepository.findByUserId(userId);
    }
}
