package com.example.userregistration.repository;

import com.example.userregistration.model.User;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

/**
 * UserRepository.java - The Repository Layer
 *
 * This interface handles all database operations for the User collection.
 *
 * By extending MongoRepository<User, String>:
 *   → Spring Data automatically provides implementations for:
 *      - save(user)         → Insert or update a document
 *      - findById(id)       → Find by MongoDB _id
 *      - findAll()          → Get all users
 *      - deleteById(id)     → Delete a document
 *      - count()            → Count all documents
 *      - existsById(id)     → Check if document exists
 *
 * We DON'T need to write SQL or MongoDB queries — Spring handles it all!
 *
 * Parameters: MongoRepository<User, String>
 *   → User   = The document class to manage
 *   → String = The type of the @Id field in User
 */
@Repository  // Tells Spring this is a database component
public interface UserRepository extends MongoRepository<User, String> {

    /**
     * Custom query method: Find a user by their userId field.
     *
     * Spring Data reads the method name "findByUserId" and automatically
     * generates the MongoDB query: { userId: "..." }
     *
     * No implementation needed — Spring does it for you!
     */
    User findByUserId(String userId);

    /**
     * Custom query method: Find a user by their username.
     * Useful for login checks (not used in this demo, but handy to have).
     */
    User findByUsername(String username);
}
