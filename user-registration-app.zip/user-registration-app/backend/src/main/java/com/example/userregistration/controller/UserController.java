package com.example.userregistration.controller;

import com.example.userregistration.model.User;
import com.example.userregistration.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * UserController.java - The Controller Layer
 *
 * The Controller handles incoming HTTP requests from the frontend.
 * It's the "front door" of our backend application.
 *
 * @RestController = @Controller + @ResponseBody
 *   → Makes this class handle HTTP requests
 *   → Automatically converts Java objects to JSON responses
 *
 * @RequestMapping("/api/users")
 *   → All endpoints in this class start with /api/users
 *   → e.g., POST /api/users, GET /api/users
 *
 * @CrossOrigin(origins = "*")
 *   → Allows requests from ANY origin (frontend on file://, localhost:3000, etc.)
 *   → This solves the CORS (Cross-Origin Resource Sharing) problem
 *   → In production, replace "*" with your actual frontend domain
 */
@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "*")   // ← CORS: allows frontend to call this backend
public class UserController {

    /**
     * Spring automatically injects the UserService here.
     * We don't need to create it with "new".
     */
    @Autowired
    private UserService userService;

    /**
     * POST /api/users
     *
     * This endpoint receives user registration data from the frontend.
     *
     * @RequestBody User user
     *   → Spring automatically converts the incoming JSON body into a User object
     *   → Example JSON: { "userId": "u1", "username": "john", ... }
     *
     * ResponseEntity<?>
     *   → Lets us control the HTTP status code and response body
     *   → 201 Created = success, 400 Bad Request = validation error, 500 = server error
     *
     * Flow:
     *   Frontend sends JSON → Controller receives it → Calls Service → Service saves to DB
     *   → Controller sends response back to frontend
     */
    @PostMapping
    public ResponseEntity<?> registerUser(@RequestBody User user) {

        // ---- Basic server-side validation ----
        // Even though the frontend validates, always validate on the server too!

        if (user.getUserId() == null || user.getUserId().isEmpty()) {
            return ResponseEntity.badRequest().body(errorResponse("userId is required"));
        }
        if (user.getUsername() == null || user.getUsername().isEmpty()) {
            return ResponseEntity.badRequest().body(errorResponse("username is required"));
        }
        if (user.getPassword() == null || user.getPassword().length() < 6) {
            return ResponseEntity.badRequest().body(errorResponse("password must be at least 6 characters"));
        }
        if (user.getName() == null || user.getName().isEmpty()) {
            return ResponseEntity.badRequest().body(errorResponse("name is required"));
        }
        if (user.getCity() == null || user.getCity().isEmpty()) {
            return ResponseEntity.badRequest().body(errorResponse("city is required"));
        }
        if (user.getDateOfBirth() == null || user.getDateOfBirth().isEmpty()) {
            return ResponseEntity.badRequest().body(errorResponse("dateOfBirth is required"));
        }

        // ---- Save the user via the Service layer ----
        try {
            User savedUser = userService.registerUser(user);

            // Build a success response JSON
            Map<String, Object> response = new HashMap<>();
            response.put("message", "User registered successfully!");
            response.put("id",          savedUser.getId());
            response.put("userId",      savedUser.getUserId());
            response.put("username",    savedUser.getUsername());
            response.put("name",        savedUser.getName());
            response.put("city",        savedUser.getCity());
            response.put("dateOfBirth", savedUser.getDateOfBirth());

            // Return 201 Created with the response body
            return ResponseEntity.status(HttpStatus.CREATED).body(response);

        } catch (Exception e) {
            // If something goes wrong, return 500 Internal Server Error
            System.err.println("❌ Error saving user: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body(errorResponse("Failed to save user: " + e.getMessage()));
        }
    }

    /**
     * GET /api/users
     *
     * Returns all registered users from MongoDB.
     * Useful for testing — call this to see all saved users.
     *
     * Example: Open browser → http://localhost:8080/api/users
     */
    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        List<User> users = userService.getAllUsers();
        return ResponseEntity.ok(users); // 200 OK with list of users
    }

    /**
     * Helper method: Create a standardized error response body.
     * Returns a Map which Spring will convert to JSON automatically.
     *
     * Example output: { "error": "userId is required" }
     */
    private Map<String, String> errorResponse(String message) {
        Map<String, String> error = new HashMap<>();
        error.put("error", message);
        return error;
    }
}
