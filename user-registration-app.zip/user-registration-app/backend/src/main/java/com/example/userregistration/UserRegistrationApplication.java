package com.example.userregistration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * UserRegistrationApplication.java
 *
 * This is the MAIN entry point of the Spring Boot application.
 *
 * @SpringBootApplication does three things:
 *   1. @Configuration     - Marks this class as a config source
 *   2. @EnableAutoConfiguration - Tells Spring Boot to auto-configure itself
 *   3. @ComponentScan     - Scans for components (controllers, services, etc.) in this package
 *
 * When you run this class, the Spring Boot server starts on port 8080.
 */
@SpringBootApplication
public class UserRegistrationApplication {

    public static void main(String[] args) {
        // This line starts the embedded Tomcat web server
        SpringApplication.run(UserRegistrationApplication.class, args);
        System.out.println("✅ Server started! Visit: http://localhost:8080");
    }
}
